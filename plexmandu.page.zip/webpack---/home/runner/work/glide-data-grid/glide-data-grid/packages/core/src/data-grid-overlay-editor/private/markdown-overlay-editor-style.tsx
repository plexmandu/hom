import { GrowingEntryStyle } from "../../growing-entry/growing-entry-style";
import { styled } from "@linaria/react";
export const MarkdownOverlayEditorStyle = styled.div`
    min-width: ${(p) => p.targetWidth}px;
    width: 100%;
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    position: relative;
    color: var(--gdg-text-dark);

    ${GrowingEntryStyle} {
        flex-shrink: 1;
        min-width: 0;
    }

    .spacer {
        flex: 1;
    }

    .edit-icon {
        position: relative;
        cursor: pointer;

        display: flex;
        justify-content: center;
        align-items: center;

        color: var(--gdg-accent-color);

        padding: 0;

        height: 24px;
        width: 24px;
        flex-shrink: 0;

        transition: all "0.125s ease";

        border-radius: 6px;

        > * {
            width: 16px;
            height: 16px;
        }
    }

    .edit-hover {
        :hover {
            background-color: var(--gdg-accent-light);
            transition: background-color 150ms;
        }
    }

    .checkmark-hover {
        :hover {
            color: #ffffff;
            background-color: var(--gdg-accent-color);
        }
    }

    .md-edit-textarea {
        position: relative;
        top: 0px;
        left: 0px;
        width: 0px;
        height: 0px;
        margin-top: 25px;
        opacity: 0;
        padding: 0;
    }

    .ml-6 {
        margin-left: 6px;
    }
`;
/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiL2hvbWUvcnVubmVyL3dvcmsvZ2xpZGUtZGF0YS1ncmlkL2dsaWRlLWRhdGEtZ3JpZC9wYWNrYWdlcy9jb3JlL3NyYy9kYXRhLWdyaWQtb3ZlcmxheS1lZGl0b3IvcHJpdmF0ZS9tYXJrZG93bi1vdmVybGF5LWVkaXRvci1zdHlsZS50c3giXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCB7IEdyb3dpbmdFbnRyeVN0eWxlIH0gZnJvbSBcIi4uLy4uL2dyb3dpbmctZW50cnkvZ3Jvd2luZy1lbnRyeS1zdHlsZVwiO1xuaW1wb3J0IHsgc3R5bGVkIH0gZnJvbSBcIkBsaW5hcmlhL3JlYWN0XCI7XG5cbmludGVyZmFjZSBQcm9wcyB7XG4gICAgdGFyZ2V0V2lkdGg6IG51bWJlcjtcbn1cblxuZXhwb3J0IGNvbnN0IE1hcmtkb3duT3ZlcmxheUVkaXRvclN0eWxlID0gc3R5bGVkLmRpdjxQcm9wcz5gXG4gICAgbWluLXdpZHRoOiAke3AgPT4gcC50YXJnZXRXaWR0aH1weDtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0O1xuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgY29sb3I6IHZhcigtLWdkZy10ZXh0LWRhcmspO1xuXG4gICAgJHtHcm93aW5nRW50cnlTdHlsZX0ge1xuICAgICAgICBmbGV4LXNocmluazogMTtcbiAgICAgICAgbWluLXdpZHRoOiAwO1xuICAgIH1cblxuICAgIC5zcGFjZXIge1xuICAgICAgICBmbGV4OiAxO1xuICAgIH1cblxuICAgIC5lZGl0LWljb24ge1xuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgICAgIGN1cnNvcjogcG9pbnRlcjtcblxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcblxuICAgICAgICBjb2xvcjogdmFyKC0tZ2RnLWFjY2VudC1jb2xvcik7XG5cbiAgICAgICAgcGFkZGluZzogMDtcblxuICAgICAgICBoZWlnaHQ6IDI0cHg7XG4gICAgICAgIHdpZHRoOiAyNHB4O1xuICAgICAgICBmbGV4LXNocmluazogMDtcblxuICAgICAgICB0cmFuc2l0aW9uOiBhbGwgXCIwLjEyNXMgZWFzZVwiO1xuXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDZweDtcblxuICAgICAgICA+ICoge1xuICAgICAgICAgICAgd2lkdGg6IDE2cHg7XG4gICAgICAgICAgICBoZWlnaHQ6IDE2cHg7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAuZWRpdC1ob3ZlciB7XG4gICAgICAgIDpob3ZlciB7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1nZGctYWNjZW50LWxpZ2h0KTtcbiAgICAgICAgICAgIHRyYW5zaXRpb246IGJhY2tncm91bmQtY29sb3IgMTUwbXM7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAuY2hlY2ttYXJrLWhvdmVyIHtcbiAgICAgICAgOmhvdmVyIHtcbiAgICAgICAgICAgIGNvbG9yOiAjZmZmZmZmO1xuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tZ2RnLWFjY2VudC1jb2xvcik7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAubWQtZWRpdC10ZXh0YXJlYSB7XG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAgICAgdG9wOiAwcHg7XG4gICAgICAgIGxlZnQ6IDBweDtcbiAgICAgICAgd2lkdGg6IDBweDtcbiAgICAgICAgaGVpZ2h0OiAwcHg7XG4gICAgICAgIG1hcmdpbi10b3A6IDI1cHg7XG4gICAgICAgIG9wYWNpdHk6IDA7XG4gICAgICAgIHBhZGRpbmc6IDA7XG4gICAgfVxuXG4gICAgLm1sLTYge1xuICAgICAgICBtYXJnaW4tbGVmdDogNnB4O1xuICAgIH1cbmA7XG4iXSwKICAibWFwcGluZ3MiOiAiQUFBQTtBQUNBO0FBTU8sYUFBTSw2QkFBNkIsT0FBTztBQUFBLGlCQUNoQyxPQUFLLEVBQUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BUWxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOyIsCiAgIm5hbWVzIjogW10KfQo=*/