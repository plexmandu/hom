import { styled } from "@linaria/react";
export const SearchWrapper = styled.div`
    position: absolute;
    top: 4px;
    right: 20px;

    background-color: var(--gdg-bg-cell);
    color: var(--gdg-text-dark);

    padding: 8px;
    border: 1px solid var(--gdg-border-color);
    border-radius: 6px;

    font-size: var(--gdg-editor-font-size);

    transform: translateX(${(p) => p.showSearch ? 0 : 400}px);
    transition: transform 0.15s;

    .search-bar-inner {
        display: flex;
    }

    .search-status {
        padding-top: 4px;
        font-size: 11px;
    }

    .search-progress {
        position: absolute;
        height: 4px;
        left: 0;
        bottom: 0;

        background-color: var(--gdg-text-light);
    }

    input {
        width: 220px;
        color: var(--gdg-textDark);
        background-color: var(--gdg-bg-cell);
        border: none;
        border-width: 0;
        outline: none;
    }

    button {
        width: 24px;
        height: 24px;
        padding: 0;

        border: none;
        outline: none;
        background: none;

        display: flex;
        justify-content: center;
        align-items: center;
        cursor: pointer;
        color: var(--gdg-text-medium);

        :hover {
            color: var(--gdg-text-dark);
        }

        .button-icon {
            width: 16px;
            height: 16px;
        }

        :disabled {
            opacity: 0.4;
            pointer-events: none;
        }
    }
`;
/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiL2hvbWUvcnVubmVyL3dvcmsvZ2xpZGUtZGF0YS1ncmlkL2dsaWRlLWRhdGEtZ3JpZC9wYWNrYWdlcy9jb3JlL3NyYy9kYXRhLWdyaWQtc2VhcmNoL2RhdGEtZ3JpZC1zZWFyY2gtc3R5bGUudHN4Il0sCiAgInNvdXJjZXNDb250ZW50IjogWyJpbXBvcnQgeyBzdHlsZWQgfSBmcm9tIFwiQGxpbmFyaWEvcmVhY3RcIjtcblxuZXhwb3J0IGNvbnN0IFNlYXJjaFdyYXBwZXIgPSBzdHlsZWQuZGl2PHsgc2hvd1NlYXJjaDogYm9vbGVhbiB9PmBcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgdG9wOiA0cHg7XG4gICAgcmlnaHQ6IDIwcHg7XG5cbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1nZGctYmctY2VsbCk7XG4gICAgY29sb3I6IHZhcigtLWdkZy10ZXh0LWRhcmspO1xuXG4gICAgcGFkZGluZzogOHB4O1xuICAgIGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLWdkZy1ib3JkZXItY29sb3IpO1xuICAgIGJvcmRlci1yYWRpdXM6IDZweDtcblxuICAgIGZvbnQtc2l6ZTogdmFyKC0tZ2RnLWVkaXRvci1mb250LXNpemUpO1xuXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKCR7cCA9PiAocC5zaG93U2VhcmNoID8gMCA6IDQwMCl9cHgpO1xuICAgIHRyYW5zaXRpb246IHRyYW5zZm9ybSAwLjE1cztcblxuICAgIC5zZWFyY2gtYmFyLWlubmVyIHtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICB9XG5cbiAgICAuc2VhcmNoLXN0YXR1cyB7XG4gICAgICAgIHBhZGRpbmctdG9wOiA0cHg7XG4gICAgICAgIGZvbnQtc2l6ZTogMTFweDtcbiAgICB9XG5cbiAgICAuc2VhcmNoLXByb2dyZXNzIHtcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICBoZWlnaHQ6IDRweDtcbiAgICAgICAgbGVmdDogMDtcbiAgICAgICAgYm90dG9tOiAwO1xuXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWdkZy10ZXh0LWxpZ2h0KTtcbiAgICB9XG5cbiAgICBpbnB1dCB7XG4gICAgICAgIHdpZHRoOiAyMjBweDtcbiAgICAgICAgY29sb3I6IHZhcigtLWdkZy10ZXh0RGFyayk7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWdkZy1iZy1jZWxsKTtcbiAgICAgICAgYm9yZGVyOiBub25lO1xuICAgICAgICBib3JkZXItd2lkdGg6IDA7XG4gICAgICAgIG91dGxpbmU6IG5vbmU7XG4gICAgfVxuXG4gICAgYnV0dG9uIHtcbiAgICAgICAgd2lkdGg6IDI0cHg7XG4gICAgICAgIGhlaWdodDogMjRweDtcbiAgICAgICAgcGFkZGluZzogMDtcblxuICAgICAgICBib3JkZXI6IG5vbmU7XG4gICAgICAgIG91dGxpbmU6IG5vbmU7XG4gICAgICAgIGJhY2tncm91bmQ6IG5vbmU7XG5cbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICAgICAgY29sb3I6IHZhcigtLWdkZy10ZXh0LW1lZGl1bSk7XG5cbiAgICAgICAgOmhvdmVyIHtcbiAgICAgICAgICAgIGNvbG9yOiB2YXIoLS1nZGctdGV4dC1kYXJrKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC5idXR0b24taWNvbiB7XG4gICAgICAgICAgICB3aWR0aDogMTZweDtcbiAgICAgICAgICAgIGhlaWdodDogMTZweDtcbiAgICAgICAgfVxuXG4gICAgICAgIDpkaXNhYmxlZCB7XG4gICAgICAgICAgICBvcGFjaXR5OiAwLjQ7XG4gICAgICAgICAgICBwb2ludGVyLWV2ZW50czogbm9uZTtcbiAgICAgICAgfVxuICAgIH1cbmA7XG4iXSwKICAibWFwcGluZ3MiOiAiQUFBQTtBQUVPLGFBQU0sZ0JBQWdCLE9BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQWNSLE9BQU0sRUFBRSxhQUFhLElBQUk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOyIsCiAgIm5hbWVzIjogW10KfQo=*/