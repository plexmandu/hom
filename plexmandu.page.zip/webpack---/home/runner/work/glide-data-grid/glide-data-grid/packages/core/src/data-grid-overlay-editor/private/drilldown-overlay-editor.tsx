import * as React from "react";
import { styled } from "@linaria/react";
const DrilldownOverlayEditorStyle = styled.div`
    display: flex;
    flex-wrap: wrap;

    .doe-bubble {
        display: flex;
        justify-content: center;
        align-items: center;

        border-radius: 100px;

        padding: 0 8px;
        height: 24px;

        background-color: var(--gdg-bg-cell);
        color: var(--gdg-text-dark);
        margin: 2px;

        border-radius: 6px;

        box-shadow: 0 0 1px rgba(62, 65, 86, 0.4), 0 1px 3px rgba(62, 65, 86, 0.4);

        img {
            height: 16px;
            object-fit: contain;

            margin-right: 4px;
        }
    }

    textarea {
        position: absolute;
        top: 0px;
        left: 0px;
        width: 0px;
        height: 0px;

        opacity: 0;
    }
`;
const DrilldownOverlayEditor = (p) => {
  const { drilldowns } = p;
  return /* @__PURE__ */ React.createElement(DrilldownOverlayEditorStyle, null, drilldowns.map((d, i) => /* @__PURE__ */ React.createElement("div", {
    key: i,
    className: "doe-bubble"
  }, d.img !== void 0 && /* @__PURE__ */ React.createElement("img", {
    src: d.img
  }), /* @__PURE__ */ React.createElement("div", null, d.text))));
};
export default DrilldownOverlayEditor;
/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiL2hvbWUvcnVubmVyL3dvcmsvZ2xpZGUtZGF0YS1ncmlkL2dsaWRlLWRhdGEtZ3JpZC9wYWNrYWdlcy9jb3JlL3NyYy9kYXRhLWdyaWQtb3ZlcmxheS1lZGl0b3IvcHJpdmF0ZS9kcmlsbGRvd24tb3ZlcmxheS1lZGl0b3IudHN4Il0sCiAgInNvdXJjZXNDb250ZW50IjogWyJpbXBvcnQgdHlwZSB7IERyaWxsZG93bkNlbGxEYXRhIH0gZnJvbSBcIi4uLy4uL2RhdGEtZ3JpZC9kYXRhLWdyaWQtdHlwZXNcIjtcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgc3R5bGVkIH0gZnJvbSBcIkBsaW5hcmlhL3JlYWN0XCI7XG5cbmNvbnN0IERyaWxsZG93bk92ZXJsYXlFZGl0b3JTdHlsZSA9IHN0eWxlZC5kaXZgXG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmbGV4LXdyYXA6IHdyYXA7XG5cbiAgICAuZG9lLWJ1YmJsZSB7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDEwMHB4O1xuXG4gICAgICAgIHBhZGRpbmc6IDAgOHB4O1xuICAgICAgICBoZWlnaHQ6IDI0cHg7XG5cbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tZ2RnLWJnLWNlbGwpO1xuICAgICAgICBjb2xvcjogdmFyKC0tZ2RnLXRleHQtZGFyayk7XG4gICAgICAgIG1hcmdpbjogMnB4O1xuXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDZweDtcblxuICAgICAgICBib3gtc2hhZG93OiAwIDAgMXB4IHJnYmEoNjIsIDY1LCA4NiwgMC40KSwgMCAxcHggM3B4IHJnYmEoNjIsIDY1LCA4NiwgMC40KTtcblxuICAgICAgICBpbWcge1xuICAgICAgICAgICAgaGVpZ2h0OiAxNnB4O1xuICAgICAgICAgICAgb2JqZWN0LWZpdDogY29udGFpbjtcblxuICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiA0cHg7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICB0ZXh0YXJlYSB7XG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgdG9wOiAwcHg7XG4gICAgICAgIGxlZnQ6IDBweDtcbiAgICAgICAgd2lkdGg6IDBweDtcbiAgICAgICAgaGVpZ2h0OiAwcHg7XG5cbiAgICAgICAgb3BhY2l0eTogMDtcbiAgICB9XG5gO1xuXG5pbnRlcmZhY2UgUHJvcHMge1xuICAgIHJlYWRvbmx5IGRyaWxsZG93bnM6IHJlYWRvbmx5IERyaWxsZG93bkNlbGxEYXRhW107XG59XG5cbmNvbnN0IERyaWxsZG93bk92ZXJsYXlFZGl0b3I6IFJlYWN0LkZ1bmN0aW9uQ29tcG9uZW50PFByb3BzPiA9IHAgPT4ge1xuICAgIGNvbnN0IHsgZHJpbGxkb3ducyB9ID0gcDtcbiAgICByZXR1cm4gKFxuICAgICAgICA8RHJpbGxkb3duT3ZlcmxheUVkaXRvclN0eWxlPlxuICAgICAgICAgICAge2RyaWxsZG93bnMubWFwKChkLCBpKSA9PiAoXG4gICAgICAgICAgICAgICAgPGRpdiBrZXk9e2l9IGNsYXNzTmFtZT1cImRvZS1idWJibGVcIj5cbiAgICAgICAgICAgICAgICAgICAge2QuaW1nICE9PSB1bmRlZmluZWQgJiYgPGltZyBzcmM9e2QuaW1nfSAvPn1cbiAgICAgICAgICAgICAgICAgICAgPGRpdj57ZC50ZXh0fTwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSl9XG4gICAgICAgIDwvRHJpbGxkb3duT3ZlcmxheUVkaXRvclN0eWxlPlxuICAgICk7XG59O1xuZXhwb3J0IGRlZmF1bHQgRHJpbGxkb3duT3ZlcmxheUVkaXRvcjtcbiJdLAogICJtYXBwaW5ncyI6ICJBQUNBO0FBQ0E7QUFFQSxNQUFNLDhCQUE4QixPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBNkMzQyxNQUFNLHlCQUF5RCxPQUFLO0FBQ2hFLFFBQU0sRUFBRSxlQUFlO0FBQ3ZCLFNBQ0ksb0NBQUMsNkJBQUQsTUFDSyxXQUFXLElBQUksQ0FBQyxHQUFHLE1BQ2hCLG9DQUFDLE9BQUQ7QUFBQSxJQUFLLEtBQUs7QUFBQSxJQUFHLFdBQVU7QUFBQSxLQUNsQixFQUFFLFFBQVEsVUFBYSxvQ0FBQyxPQUFEO0FBQUEsSUFBSyxLQUFLLEVBQUU7QUFBQSxNQUNwQyxvQ0FBQyxPQUFELE1BQU0sRUFBRTtBQUFBO0FBTTVCLGVBQWU7IiwKICAibmFtZXMiOiBbXQp9Cg==*/