import React from "react";
import { styled } from "@linaria/react";
import { css } from "@linaria/core";
import ClickOutsideContainer from "../click-outside-container/click-outside-container";
const RenameInput = styled.input`
    flex-grow: 1;
    border: none;
    outline: none;
    background-color: var(--gdg-bg-header-has-focus);
    border-radius: 9px;
    padding: 0 8px;
    box-shadow: 0 0 0 1px var(--gdg-border-color);
    color: var(--gdg-text-group-header);
    min-height: ${(p) => Math.max(16, p.targetHeight - 10)}px;
    font: var(--gdg-header-font-style) var(--gdg-font-family);
`;
export const GroupRename = (p) => {
  const { bounds, group, onClose, canvasBounds, onFinish } = p;
  const [value, setValue] = React.useState(group);
  return /* @__PURE__ */ React.createElement(ClickOutsideContainer, {
    style: {
      position: "absolute",
      left: bounds.x - canvasBounds.left + 1,
      top: bounds.y - canvasBounds.top,
      width: bounds.width - 2,
      height: bounds.height
    },
    className: css`
                padding: 0 8px;
                display: flex;
                align-items: center;
                background-color: var(--gdg-bg-header);
            `,
    onClickOutside: onClose
  }, /* @__PURE__ */ React.createElement(RenameInput, {
    targetHeight: bounds.height,
    "data-testid": "group-rename-input",
    value,
    onBlur: onClose,
    onFocus: (e) => e.target.setSelectionRange(0, value.length),
    onChange: (e) => setValue(e.target.value),
    onKeyDown: (e) => {
      if (e.key === "Enter") {
        onFinish(value);
      } else if (e.key === "Escape") {
        onClose();
      }
    },
    autoFocus: true
  }));
};
/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiL2hvbWUvcnVubmVyL3dvcmsvZ2xpZGUtZGF0YS1ncmlkL2dsaWRlLWRhdGEtZ3JpZC9wYWNrYWdlcy9jb3JlL3NyYy9kYXRhLWVkaXRvci9ncm91cC1yZW5hbWUudHN4Il0sCiAgInNvdXJjZXNDb250ZW50IjogWyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBzdHlsZWQgfSBmcm9tIFwiQGxpbmFyaWEvcmVhY3RcIjtcbmltcG9ydCB7IGNzcyB9IGZyb20gXCJAbGluYXJpYS9jb3JlXCI7XG5pbXBvcnQgQ2xpY2tPdXRzaWRlQ29udGFpbmVyIGZyb20gXCIuLi9jbGljay1vdXRzaWRlLWNvbnRhaW5lci9jbGljay1vdXRzaWRlLWNvbnRhaW5lclwiO1xuaW1wb3J0IHR5cGUgeyBSZWN0YW5nbGUgfSBmcm9tIFwiLi4vZGF0YS1ncmlkL2RhdGEtZ3JpZC10eXBlc1wiO1xuXG5pbnRlcmZhY2UgUHJvcHMge1xuICAgIHJlYWRvbmx5IGJvdW5kczogUmVjdGFuZ2xlO1xuICAgIHJlYWRvbmx5IGdyb3VwOiBzdHJpbmc7XG4gICAgcmVhZG9ubHkgb25DbG9zZTogKCkgPT4gdm9pZDtcbiAgICByZWFkb25seSBvbkZpbmlzaDogKG5ld1ZhbDogc3RyaW5nKSA9PiB2b2lkO1xuICAgIHJlYWRvbmx5IGNhbnZhc0JvdW5kczogRE9NUmVjdDtcbn1cblxuY29uc3QgUmVuYW1lSW5wdXQgPSBzdHlsZWQuaW5wdXQ8eyB0YXJnZXRIZWlnaHQ6IG51bWJlciB9PmBcbiAgICBmbGV4LWdyb3c6IDE7XG4gICAgYm9yZGVyOiBub25lO1xuICAgIG91dGxpbmU6IG5vbmU7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tZ2RnLWJnLWhlYWRlci1oYXMtZm9jdXMpO1xuICAgIGJvcmRlci1yYWRpdXM6IDlweDtcbiAgICBwYWRkaW5nOiAwIDhweDtcbiAgICBib3gtc2hhZG93OiAwIDAgMCAxcHggdmFyKC0tZ2RnLWJvcmRlci1jb2xvcik7XG4gICAgY29sb3I6IHZhcigtLWdkZy10ZXh0LWdyb3VwLWhlYWRlcik7XG4gICAgbWluLWhlaWdodDogJHtwID0+IE1hdGgubWF4KDE2LCBwLnRhcmdldEhlaWdodCAtIDEwKX1weDtcbiAgICBmb250OiB2YXIoLS1nZGctaGVhZGVyLWZvbnQtc3R5bGUpIHZhcigtLWdkZy1mb250LWZhbWlseSk7XG5gO1xuXG5leHBvcnQgY29uc3QgR3JvdXBSZW5hbWU6IFJlYWN0LlZGQzxQcm9wcz4gPSBwID0+IHtcbiAgICBjb25zdCB7IGJvdW5kcywgZ3JvdXAsIG9uQ2xvc2UsIGNhbnZhc0JvdW5kcywgb25GaW5pc2ggfSA9IHA7XG5cbiAgICBjb25zdCBbdmFsdWUsIHNldFZhbHVlXSA9IFJlYWN0LnVzZVN0YXRlKGdyb3VwKTtcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxDbGlja091dHNpZGVDb250YWluZXJcbiAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgcG9zaXRpb246IFwiYWJzb2x1dGVcIixcbiAgICAgICAgICAgICAgICBsZWZ0OiBib3VuZHMueCAtIGNhbnZhc0JvdW5kcy5sZWZ0ICsgMSxcbiAgICAgICAgICAgICAgICB0b3A6IGJvdW5kcy55IC0gY2FudmFzQm91bmRzLnRvcCxcbiAgICAgICAgICAgICAgICB3aWR0aDogYm91bmRzLndpZHRoIC0gMixcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IGJvdW5kcy5oZWlnaHQsXG4gICAgICAgICAgICB9fVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtjc3NgXG4gICAgICAgICAgICAgICAgcGFkZGluZzogMCA4cHg7XG4gICAgICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWdkZy1iZy1oZWFkZXIpO1xuICAgICAgICAgICAgYH1cbiAgICAgICAgICAgIG9uQ2xpY2tPdXRzaWRlPXtvbkNsb3NlfT5cbiAgICAgICAgICAgIDxSZW5hbWVJbnB1dFxuICAgICAgICAgICAgICAgIHRhcmdldEhlaWdodD17Ym91bmRzLmhlaWdodH1cbiAgICAgICAgICAgICAgICBkYXRhLXRlc3RpZD1cImdyb3VwLXJlbmFtZS1pbnB1dFwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e3ZhbHVlfVxuICAgICAgICAgICAgICAgIG9uQmx1cj17b25DbG9zZX1cbiAgICAgICAgICAgICAgICBvbkZvY3VzPXtlID0+IGUudGFyZ2V0LnNldFNlbGVjdGlvblJhbmdlKDAsIHZhbHVlLmxlbmd0aCl9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0VmFsdWUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIG9uS2V5RG93bj17ZSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChlLmtleSA9PT0gXCJFbnRlclwiKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkZpbmlzaCh2YWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoZS5rZXkgPT09IFwiRXNjYXBlXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xvc2UoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgYXV0b0ZvY3VzPXt0cnVlfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgPC9DbGlja091dHNpZGVDb250YWluZXI+XG4gICAgKTtcbn07XG4iXSwKICAibWFwcGluZ3MiOiAiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQVdBLE1BQU0sY0FBYyxPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVNULE9BQUssS0FBSyxJQUFJLElBQUksRUFBRSxlQUFlO0FBQUE7QUFBQTtBQUk5QyxhQUFNLGNBQWdDLE9BQUs7QUFDOUMsUUFBTSxFQUFFLFFBQVEsT0FBTyxTQUFTLGNBQWMsYUFBYTtBQUUzRCxRQUFNLENBQUMsT0FBTyxZQUFZLE1BQU0sU0FBUztBQUV6QyxTQUNJLG9DQUFDLHVCQUFEO0FBQUEsSUFDSSxPQUFPO0FBQUEsTUFDSCxVQUFVO0FBQUEsTUFDVixNQUFNLE9BQU8sSUFBSSxhQUFhLE9BQU87QUFBQSxNQUNyQyxLQUFLLE9BQU8sSUFBSSxhQUFhO0FBQUEsTUFDN0IsT0FBTyxPQUFPLFFBQVE7QUFBQSxNQUN0QixRQUFRLE9BQU87QUFBQTtBQUFBLElBRW5CLFdBQVc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFNWCxnQkFBZ0I7QUFBQSxLQUNoQixvQ0FBQyxhQUFEO0FBQUEsSUFDSSxjQUFjLE9BQU87QUFBQSxJQUNyQixlQUFZO0FBQUEsSUFDWjtBQUFBLElBQ0EsUUFBUTtBQUFBLElBQ1IsU0FBUyxPQUFLLEVBQUUsT0FBTyxrQkFBa0IsR0FBRyxNQUFNO0FBQUEsSUFDbEQsVUFBVSxPQUFLLFNBQVMsRUFBRSxPQUFPO0FBQUEsSUFDakMsV0FBVyxPQUFLO0FBQ1osVUFBSSxFQUFFLFFBQVEsU0FBUztBQUNuQixpQkFBUztBQUFBLGlCQUNGLEVBQUUsUUFBUSxVQUFVO0FBQzNCO0FBQUE7QUFBQTtBQUFBLElBR1IsV0FBVztBQUFBO0FBQUE7IiwKICAibmFtZXMiOiBbXQp9Cg==*/