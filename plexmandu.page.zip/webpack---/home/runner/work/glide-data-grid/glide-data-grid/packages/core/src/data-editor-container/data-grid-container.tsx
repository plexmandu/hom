import { styled } from "@linaria/react";
import * as React from "react";
function toCss(x) {
  if (typeof x === "string")
    return x;
  return `${x}px`;
}
const Wrapper = styled.div`
    position: relative;

    min-width: 10px;
    min-height: 10px;
    max-width: 100%;
    max-height: 100%;

    width: ${(p) => p.innerWidth};
    height: ${(p) => p.innerHeight};

    overflow: hidden;
    overflow: clip;

    contain: strict;

    direction: ltr;

    > :first-child {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
    }
`;
export const DataEditorContainer = (p) => {
  const { inWidth, inHeight, children, ...rest } = p;
  return /* @__PURE__ */ React.createElement(Wrapper, {
    innerHeight: toCss(inHeight),
    innerWidth: toCss(inWidth),
    ...rest
  }, children);
};
/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiL2hvbWUvcnVubmVyL3dvcmsvZ2xpZGUtZGF0YS1ncmlkL2dsaWRlLWRhdGEtZ3JpZC9wYWNrYWdlcy9jb3JlL3NyYy9kYXRhLWVkaXRvci1jb250YWluZXIvZGF0YS1ncmlkLWNvbnRhaW5lci50c3giXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCB7IHN0eWxlZCB9IGZyb20gXCJAbGluYXJpYS9yZWFjdFwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5cbmludGVyZmFjZSBXcmFwcGVyUHJvcHMge1xuICAgIGluV2lkdGg6IG51bWJlciB8IHN0cmluZztcbiAgICBpbkhlaWdodDogbnVtYmVyIHwgc3RyaW5nO1xufVxuXG5mdW5jdGlvbiB0b0Nzcyh4OiBudW1iZXIgfCBzdHJpbmcpIHtcbiAgICBpZiAodHlwZW9mIHggPT09IFwic3RyaW5nXCIpIHJldHVybiB4O1xuICAgIHJldHVybiBgJHt4fXB4YDtcbn1cblxuY29uc3QgV3JhcHBlciA9IHN0eWxlZC5kaXY8eyBpbm5lcldpZHRoOiBzdHJpbmc7IGlubmVySGVpZ2h0OiBzdHJpbmcgfT5gXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuXG4gICAgbWluLXdpZHRoOiAxMHB4O1xuICAgIG1pbi1oZWlnaHQ6IDEwcHg7XG4gICAgbWF4LXdpZHRoOiAxMDAlO1xuICAgIG1heC1oZWlnaHQ6IDEwMCU7XG5cbiAgICB3aWR0aDogJHtwID0+IHAuaW5uZXJXaWR0aH07XG4gICAgaGVpZ2h0OiAke3AgPT4gcC5pbm5lckhlaWdodH07XG5cbiAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgIG92ZXJmbG93OiBjbGlwO1xuXG4gICAgY29udGFpbjogc3RyaWN0O1xuXG4gICAgZGlyZWN0aW9uOiBsdHI7XG5cbiAgICA+IDpmaXJzdC1jaGlsZCB7XG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgICAgbGVmdDogMDtcbiAgICAgICAgdG9wOiAwO1xuICAgICAgICB3aWR0aDogMTAwJTtcbiAgICAgICAgaGVpZ2h0OiAxMDAlO1xuICAgIH1cbmA7XG5cbmludGVyZmFjZSBQcm9wcyBleHRlbmRzIFdyYXBwZXJQcm9wcywgUmVhY3QuSFRNTEF0dHJpYnV0ZXM8SFRNTERpdkVsZW1lbnQ+IHt9XG5cbmV4cG9ydCBjb25zdCBEYXRhRWRpdG9yQ29udGFpbmVyOiBSZWFjdC5GdW5jdGlvbkNvbXBvbmVudDxSZWFjdC5Qcm9wc1dpdGhDaGlsZHJlbjxQcm9wcz4+ID0gcCA9PiB7XG4gICAgY29uc3QgeyBpbldpZHRoLCBpbkhlaWdodCwgY2hpbGRyZW4sIC4uLnJlc3QgfSA9IHA7XG4gICAgcmV0dXJuIChcbiAgICAgICAgPFdyYXBwZXIgaW5uZXJIZWlnaHQ9e3RvQ3NzKGluSGVpZ2h0KX0gaW5uZXJXaWR0aD17dG9Dc3MoaW5XaWR0aCl9IHsuLi5yZXN0fT5cbiAgICAgICAgICAgIHtjaGlsZHJlbn1cbiAgICAgICAgPC9XcmFwcGVyPlxuICAgICk7XG59O1xuIl0sCiAgIm1hcHBpbmdzIjogIkFBQUE7QUFDQTtBQU9BLGVBQWUsR0FBb0I7QUFDL0IsTUFBSSxPQUFPLE1BQU07QUFBVSxXQUFPO0FBQ2xDLFNBQU8sR0FBRztBQUFBO0FBR2QsTUFBTSxVQUFVLE9BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUVYsT0FBSyxFQUFFO0FBQUEsY0FDTixPQUFLLEVBQUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQW9CZCxhQUFNLHNCQUErRSxPQUFLO0FBQzdGLFFBQU0sRUFBRSxTQUFTLFVBQVUsYUFBYSxTQUFTO0FBQ2pELFNBQ0ksb0NBQUMsU0FBRDtBQUFBLElBQVMsYUFBYSxNQUFNO0FBQUEsSUFBVyxZQUFZLE1BQU07QUFBQSxPQUFjO0FBQUEsS0FDbEU7QUFBQTsiLAogICJuYW1lcyI6IFtdCn0K*/