import { styled } from "@linaria/react";
export const DataGridOverlayEditorStyle = styled.div`
    position: absolute;

    display: flex;
    flex-direction: column;
    overflow: hidden;
    box-sizing: border-box;

    --overlay-top: ${(p) => p.targetY}px;

    left: ${(p) => p.targetX - 1}px;
    top: ${(p) => p.targetY - 1}px;
    min-width: ${(p) => p.targetWidth + 2}px;
    min-height: ${(p) => p.targetHeight + 2}px;
    width: max-content;
    max-width: 400px;
    max-height: calc(100vh - ${(p) => p.targetY + 10}px);

    font-family: var(--gdg-font-family);
    font-size: var(--gdg-editor-font-size);

    @keyframes glide_fade_in {
        from {
            opacity: 0%;
        }

        to {
            opacity: 100%;
        }
    }

    &.gdg-style {
        border-radius: 2px;
        background-color: var(--gdg-bg-cell);

        box-shadow: 0 0 0 1px var(--gdg-accent-color), 0px 0px 1px rgba(62, 65, 86, 0.4),
            0px 6px 12px rgba(62, 65, 86, 0.15);

        animation: glide_fade_in 60ms 1;
    }

    &.pad {
        padding: ${(p) => Math.max(0, (p.targetHeight - 28) / 2)}px 8.5px 3px;
    }

    .clip-region {
        display: flex;
        flex-direction: column;
        overflow-y: auto;
        overflow-x: hidden;
        border-radius: 2px;
        flex-grow: 1;

        .gdg-growing-entry {
            height: 100%;
        }

        & input.gdg-input {
            width: 100%;
            border: none;
            border-width: 0;
            outline: none;
        }

        & textarea.gdg-input {
            border: none;
            border-width: 0;
            outline: none;
        }
    }

    text-align: start;
`;
/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiL2hvbWUvcnVubmVyL3dvcmsvZ2xpZGUtZGF0YS1ncmlkL2dsaWRlLWRhdGEtZ3JpZC9wYWNrYWdlcy9jb3JlL3NyYy9kYXRhLWdyaWQtb3ZlcmxheS1lZGl0b3IvZGF0YS1ncmlkLW92ZXJsYXktZWRpdG9yLXN0eWxlLnRzeCJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiaW1wb3J0IHsgc3R5bGVkIH0gZnJvbSBcIkBsaW5hcmlhL3JlYWN0XCI7XG5cbmludGVyZmFjZSBQcm9wcyB7XG4gICAgdGFyZ2V0WDogbnVtYmVyO1xuICAgIHRhcmdldFk6IG51bWJlcjtcbiAgICB0YXJnZXRXaWR0aDogbnVtYmVyO1xuICAgIHRhcmdldEhlaWdodDogbnVtYmVyO1xufVxuZXhwb3J0IGNvbnN0IERhdGFHcmlkT3ZlcmxheUVkaXRvclN0eWxlID0gc3R5bGVkLmRpdjxQcm9wcz5gXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuXG4gICAgZGlzcGxheTogZmxleDtcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICAgIG92ZXJmbG93OiBoaWRkZW47XG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcblxuICAgIC0tb3ZlcmxheS10b3A6ICR7cCA9PiBwLnRhcmdldFl9cHg7XG5cbiAgICBsZWZ0OiAke3AgPT4gcC50YXJnZXRYIC0gMX1weDtcbiAgICB0b3A6ICR7cCA9PiBwLnRhcmdldFkgLSAxfXB4O1xuICAgIG1pbi13aWR0aDogJHtwID0+IHAudGFyZ2V0V2lkdGggKyAyfXB4O1xuICAgIG1pbi1oZWlnaHQ6ICR7cCA9PiBwLnRhcmdldEhlaWdodCArIDJ9cHg7XG4gICAgd2lkdGg6IG1heC1jb250ZW50O1xuICAgIG1heC13aWR0aDogNDAwcHg7XG4gICAgbWF4LWhlaWdodDogY2FsYygxMDB2aCAtICR7cCA9PiBwLnRhcmdldFkgKyAxMH1weCk7XG5cbiAgICBmb250LWZhbWlseTogdmFyKC0tZ2RnLWZvbnQtZmFtaWx5KTtcbiAgICBmb250LXNpemU6IHZhcigtLWdkZy1lZGl0b3ItZm9udC1zaXplKTtcblxuICAgIEBrZXlmcmFtZXMgZ2xpZGVfZmFkZV9pbiB7XG4gICAgICAgIGZyb20ge1xuICAgICAgICAgICAgb3BhY2l0eTogMCU7XG4gICAgICAgIH1cblxuICAgICAgICB0byB7XG4gICAgICAgICAgICBvcGFjaXR5OiAxMDAlO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgJi5nZGctc3R5bGUge1xuICAgICAgICBib3JkZXItcmFkaXVzOiAycHg7XG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWdkZy1iZy1jZWxsKTtcblxuICAgICAgICBib3gtc2hhZG93OiAwIDAgMCAxcHggdmFyKC0tZ2RnLWFjY2VudC1jb2xvciksIDBweCAwcHggMXB4IHJnYmEoNjIsIDY1LCA4NiwgMC40KSxcbiAgICAgICAgICAgIDBweCA2cHggMTJweCByZ2JhKDYyLCA2NSwgODYsIDAuMTUpO1xuXG4gICAgICAgIGFuaW1hdGlvbjogZ2xpZGVfZmFkZV9pbiA2MG1zIDE7XG4gICAgfVxuXG4gICAgJi5wYWQge1xuICAgICAgICBwYWRkaW5nOiAke3AgPT4gTWF0aC5tYXgoMCwgKHAudGFyZ2V0SGVpZ2h0IC0gMjgpIC8gMil9cHggOC41cHggM3B4O1xuICAgIH1cblxuICAgIC5jbGlwLXJlZ2lvbiB7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgICAgIG92ZXJmbG93LXk6IGF1dG87XG4gICAgICAgIG92ZXJmbG93LXg6IGhpZGRlbjtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMnB4O1xuICAgICAgICBmbGV4LWdyb3c6IDE7XG5cbiAgICAgICAgLmdkZy1ncm93aW5nLWVudHJ5IHtcbiAgICAgICAgICAgIGhlaWdodDogMTAwJTtcbiAgICAgICAgfVxuXG4gICAgICAgICYgaW5wdXQuZ2RnLWlucHV0IHtcbiAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgICAgYm9yZGVyOiBub25lO1xuICAgICAgICAgICAgYm9yZGVyLXdpZHRoOiAwO1xuICAgICAgICAgICAgb3V0bGluZTogbm9uZTtcbiAgICAgICAgfVxuXG4gICAgICAgICYgdGV4dGFyZWEuZ2RnLWlucHV0IHtcbiAgICAgICAgICAgIGJvcmRlcjogbm9uZTtcbiAgICAgICAgICAgIGJvcmRlci13aWR0aDogMDtcbiAgICAgICAgICAgIG91dGxpbmU6IG5vbmU7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICB0ZXh0LWFsaWduOiBzdGFydDtcbmA7XG4iXSwKICAibWFwcGluZ3MiOiAiQUFBQTtBQVFPLGFBQU0sNkJBQTZCLE9BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVE1QixPQUFLLEVBQUU7QUFBQTtBQUFBLFlBRWhCLE9BQUssRUFBRSxVQUFVO0FBQUEsV0FDbEIsT0FBSyxFQUFFLFVBQVU7QUFBQSxpQkFDWCxPQUFLLEVBQUUsY0FBYztBQUFBLGtCQUNwQixPQUFLLEVBQUUsZUFBZTtBQUFBO0FBQUE7QUFBQSwrQkFHVCxPQUFLLEVBQUUsVUFBVTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMEI3QixPQUFLLEtBQUssSUFBSSxHQUFJLEdBQUUsZUFBZSxNQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOyIsCiAgIm5hbWVzIjogW10KfQo=*/