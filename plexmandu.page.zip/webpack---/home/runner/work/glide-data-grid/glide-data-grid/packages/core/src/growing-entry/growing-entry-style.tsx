import { styled } from "@linaria/react";
export const InputBox = styled.textarea`
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    width: 100%;
    height: 100%;

    border-radius: 0px;

    resize: none;
    white-space: pre-wrap;
    min-width: 100%;
    overflow: hidden;
    border: 0;
    background-color: transparent;

    ::placeholder {
        color: var(--gdg-text-light);
    }

    font-size: var(--gdg-editor-font-size);
    line-height: 16px;
    font-family: var(--gdg-font-family);
    color: var(--gdg-text-dark);
    padding: 0;
    margin: 0;

    .invalid & {
        text-decoration: underline;
        text-decoration-color: #d60606;
    }
`;
export const ShadowBox = styled.div`
    visibility: hidden;
    white-space: pre-wrap;
    word-wrap: break-word;

    width: max-content;
    max-width: 100%;

    min-width: 100%;

    font-size: var(--gdg-editor-font-size);
    line-height: 16px;
    font-family: var(--gdg-font-family);
    color: var(--gdg-text-dark);
    padding: 0;
    margin: 0;

    padding-bottom: 2px;
`;
export const GrowingEntryStyle = styled.div`
    position: relative;
    margin-top: 6px;
`;
/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiL2hvbWUvcnVubmVyL3dvcmsvZ2xpZGUtZGF0YS1ncmlkL2dsaWRlLWRhdGEtZ3JpZC9wYWNrYWdlcy9jb3JlL3NyYy9ncm93aW5nLWVudHJ5L2dyb3dpbmctZW50cnktc3R5bGUudHN4Il0sCiAgInNvdXJjZXNDb250ZW50IjogWyJpbXBvcnQgeyBzdHlsZWQgfSBmcm9tIFwiQGxpbmFyaWEvcmVhY3RcIjtcblxuZXhwb3J0IGNvbnN0IElucHV0Qm94ID0gc3R5bGVkLnRleHRhcmVhYFxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICBsZWZ0OiAwO1xuICAgIHJpZ2h0OiAwO1xuICAgIHRvcDogMDtcbiAgICBib3R0b206IDA7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAxMDAlO1xuXG4gICAgYm9yZGVyLXJhZGl1czogMHB4O1xuXG4gICAgcmVzaXplOiBub25lO1xuICAgIHdoaXRlLXNwYWNlOiBwcmUtd3JhcDtcbiAgICBtaW4td2lkdGg6IDEwMCU7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICBib3JkZXI6IDA7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XG5cbiAgICA6OnBsYWNlaG9sZGVyIHtcbiAgICAgICAgY29sb3I6IHZhcigtLWdkZy10ZXh0LWxpZ2h0KTtcbiAgICB9XG5cbiAgICBmb250LXNpemU6IHZhcigtLWdkZy1lZGl0b3ItZm9udC1zaXplKTtcbiAgICBsaW5lLWhlaWdodDogMTZweDtcbiAgICBmb250LWZhbWlseTogdmFyKC0tZ2RnLWZvbnQtZmFtaWx5KTtcbiAgICBjb2xvcjogdmFyKC0tZ2RnLXRleHQtZGFyayk7XG4gICAgcGFkZGluZzogMDtcbiAgICBtYXJnaW46IDA7XG5cbiAgICAuaW52YWxpZCAmIHtcbiAgICAgICAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XG4gICAgICAgIHRleHQtZGVjb3JhdGlvbi1jb2xvcjogI2Q2MDYwNjtcbiAgICB9XG5gO1xuXG5leHBvcnQgY29uc3QgU2hhZG93Qm94ID0gc3R5bGVkLmRpdmBcbiAgICB2aXNpYmlsaXR5OiBoaWRkZW47XG4gICAgd2hpdGUtc3BhY2U6IHByZS13cmFwO1xuICAgIHdvcmQtd3JhcDogYnJlYWstd29yZDtcblxuICAgIHdpZHRoOiBtYXgtY29udGVudDtcbiAgICBtYXgtd2lkdGg6IDEwMCU7XG5cbiAgICBtaW4td2lkdGg6IDEwMCU7XG5cbiAgICBmb250LXNpemU6IHZhcigtLWdkZy1lZGl0b3ItZm9udC1zaXplKTtcbiAgICBsaW5lLWhlaWdodDogMTZweDtcbiAgICBmb250LWZhbWlseTogdmFyKC0tZ2RnLWZvbnQtZmFtaWx5KTtcbiAgICBjb2xvcjogdmFyKC0tZ2RnLXRleHQtZGFyayk7XG4gICAgcGFkZGluZzogMDtcbiAgICBtYXJnaW46IDA7XG5cbiAgICBwYWRkaW5nLWJvdHRvbTogMnB4O1xuYDtcblxuZXhwb3J0IGNvbnN0IEdyb3dpbmdFbnRyeVN0eWxlID0gc3R5bGVkLmRpdmBcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgbWFyZ2luLXRvcDogNnB4O1xuYDtcbiJdLAogICJtYXBwaW5ncyI6ICJBQUFBO0FBRU8sYUFBTSxXQUFXLE9BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFtQ3hCLGFBQU0sWUFBWSxPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBb0J6QixhQUFNLG9CQUFvQixPQUFPO0FBQUE7QUFBQTtBQUFBOyIsCiAgIm5hbWVzIjogW10KfQo=*/