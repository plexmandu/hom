import { styled } from "@linaria/react";
export const ImageOverlayEditorStyle = styled.div`
    display: flex;

    height: 100%;

    .centering-container {
        display: flex;
        justify-content: center;
        align-items: center;

        height: 100%;

        img,
        canvas {
            max-height: calc(100vh - var(--overlay-top) - 20px);
            object-fit: contain;
            user-select: none;
        }

        canvas {
            max-width: 380px;
        }
    }

    .edit-icon {
        position: absolute;
        top: 12px;
        right: 0;
        width: 48px;
        height: 48px;
        color: var(--gdg-accent-color);

        cursor: pointer;

        display: flex;
        justify-content: center;
        align-items: center;

        > * {
            width: 24px;
            height: 24px;
        }
    }

    textarea {
        position: absolute;
        top: 0px;
        left: 0px;
        width: 0px;
        height: 0px;

        opacity: 0;
    }
`;
/*# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiL2hvbWUvcnVubmVyL3dvcmsvZ2xpZGUtZGF0YS1ncmlkL2dsaWRlLWRhdGEtZ3JpZC9wYWNrYWdlcy9jb3JlL3NyYy9kYXRhLWdyaWQtb3ZlcmxheS1lZGl0b3IvcHJpdmF0ZS9pbWFnZS1vdmVybGF5LWVkaXRvci1zdHlsZS50c3giXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCB7IHN0eWxlZCB9IGZyb20gXCJAbGluYXJpYS9yZWFjdFwiO1xuXG5leHBvcnQgY29uc3QgSW1hZ2VPdmVybGF5RWRpdG9yU3R5bGUgPSBzdHlsZWQuZGl2YFxuICAgIGRpc3BsYXk6IGZsZXg7XG5cbiAgICBoZWlnaHQ6IDEwMCU7XG5cbiAgICAuY2VudGVyaW5nLWNvbnRhaW5lciB7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuXG4gICAgICAgIGhlaWdodDogMTAwJTtcblxuICAgICAgICBpbWcsXG4gICAgICAgIGNhbnZhcyB7XG4gICAgICAgICAgICBtYXgtaGVpZ2h0OiBjYWxjKDEwMHZoIC0gdmFyKC0tb3ZlcmxheS10b3ApIC0gMjBweCk7XG4gICAgICAgICAgICBvYmplY3QtZml0OiBjb250YWluO1xuICAgICAgICAgICAgdXNlci1zZWxlY3Q6IG5vbmU7XG4gICAgICAgIH1cblxuICAgICAgICBjYW52YXMge1xuICAgICAgICAgICAgbWF4LXdpZHRoOiAzODBweDtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5lZGl0LWljb24ge1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIHRvcDogMTJweDtcbiAgICAgICAgcmlnaHQ6IDA7XG4gICAgICAgIHdpZHRoOiA0OHB4O1xuICAgICAgICBoZWlnaHQ6IDQ4cHg7XG4gICAgICAgIGNvbG9yOiB2YXIoLS1nZGctYWNjZW50LWNvbG9yKTtcblxuICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XG5cbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG5cbiAgICAgICAgPiAqIHtcbiAgICAgICAgICAgIHdpZHRoOiAyNHB4O1xuICAgICAgICAgICAgaGVpZ2h0OiAyNHB4O1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgdGV4dGFyZWEge1xuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgIHRvcDogMHB4O1xuICAgICAgICBsZWZ0OiAwcHg7XG4gICAgICAgIHdpZHRoOiAwcHg7XG4gICAgICAgIGhlaWdodDogMHB4O1xuXG4gICAgICAgIG9wYWNpdHk6IDA7XG4gICAgfVxuYDtcbiJdLAogICJtYXBwaW5ncyI6ICJBQUFBO0FBRU8sYUFBTSwwQkFBMEIsT0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7IiwKICAibmFtZXMiOiBbXQp9Cg==*/